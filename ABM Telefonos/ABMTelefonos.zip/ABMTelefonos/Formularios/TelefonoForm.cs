﻿using ABMTelefonos.Acceso_a_Datos.Implementaciones;
using ABMTelefonos.Entidades;
using ABMTelefonos.Servicios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ABMTelefonos.Formularios
{
    public partial class TelefonoForm : Form
    {
        private GestorTelefono gestor;
        private Telefono oTelefono;
        public TelefonoForm()
        {
            InitializeComponent();
            gestor = new GestorTelefono(new DaoFactory());
            oTelefono = new Telefono();
        }

        private void TelefonoForm_Load(object sender, EventArgs e)
        {
            CargarCombo();
            CargarLista();
            HabilitarCampos(false);
        }

        private void CargarLista()
        {
            DataTable table = new DataTable();

            table = gestor.CargarListaTelefonos();

            lstTelefonos.DataSource = table;
            lstTelefonos.DisplayMember = "Lista";

           
        }

        private void CargarCombo()
        {
            DataTable table = new DataTable();

            table = gestor.CargarComboMarca();

            cboMarca.DataSource = table;
            cboMarca.DisplayMember = "nombreMarca";
            cboMarca.ValueMember = "idMarca";
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            HabilitarCampos(true);


        }

        private void HabilitarCampos(bool habilitar)
        {
            

            txtCodigo.Enabled = habilitar;
            txtNombre.Enabled = habilitar;
            txtPrecio.Enabled = habilitar;
            btnEditar.Visible = !habilitar;
            lstTelefonos.Enabled = !habilitar;
            cboMarca.Enabled = habilitar;
            btnNuevo.Enabled = !habilitar;
            btnSalir.Enabled = !habilitar;
            btnBorrar.Enabled = !habilitar;
            btnGrabar.Enabled = habilitar;


        }

        public void ValidarCampos() 
        {
            if (txtCodigo.Text == null || txtNombre.Text == null || txtPrecio.Text == null)
            {
                MessageBox.Show("Cargue todos los campos por favor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }

            if (cboMarca.SelectedIndex == -1)
            {
                MessageBox.Show("Cargue una marca por favor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }

            int codigo;
            double precio;

            try
            {
                codigo = Convert.ToInt32(txtCodigo.Text);
                precio = Convert.ToDouble(txtPrecio.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Introduzca un valor numerico!");
                return;
            }

        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            ValidarCampos();

            oTelefono.Codigo = Convert.ToInt32(txtCodigo.Text);
            oTelefono.Nombre = txtNombre.Text;
            oTelefono.Marca = Convert.ToInt32(cboMarca.SelectedValue);
            oTelefono.Precio = Convert.ToDouble(txtPrecio.Text);

            if (gestor.GrabarTelefono(oTelefono))
            {
                MessageBox.Show("Telefono Cargado exitosamente", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarLista();

            }
            else 
            {
                MessageBox.Show("No se ha podido cargar el telefono");
            }
        }
    }
}
