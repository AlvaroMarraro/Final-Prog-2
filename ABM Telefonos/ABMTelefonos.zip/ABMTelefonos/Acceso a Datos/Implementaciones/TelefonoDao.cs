﻿using ABMTelefonos.Acceso_a_Datos.Interfaces;
using ABMTelefonos.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABMTelefonos.Acceso_a_Datos.Implementaciones
{
    class TelefonoDao : ITelefonoDao
    {
        public DataTable CargarCombo()
        {
            DataTable tabla = new DataTable();

            string query = "SELECT * FROM Marcas";

            tabla = HelperDao.ObtenerInstancia().ConsultaSQL(query);

            return tabla;
        }

        public DataTable CargarListaTelefonos()
        {
            DataTable tabla = new DataTable();

            string query = "Select CONVERT(varchar, T.codigo) + ' - ' + T.nombre as 'Lista'  FROM Telefonos T ORDER BY 1";

            tabla = HelperDao.ObtenerInstancia().ConsultaSQL(query);

            return tabla;
        }

        

        public bool GrabarTelefono(Telefono oTelefono)
        {
            int filasAfectadas = 0;
            bool resultado = true;

            string query = "INSERT INTO Telefonos values (@codigo, @nombre, @marca, @precio)";

            filasAfectadas = HelperDao.ObtenerInstancia().GrabarNuevoTelefono(query, oTelefono);

            if (filasAfectadas == 0) resultado = false;

            return resultado;
        }
    }
}
